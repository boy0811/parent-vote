from flask import Flask, request, jsonify, render_template
from threading import Thread
import time

app = Flask(__name__)

votes = {str(i): 0 for i in range(1, 181)}
user_votes = {}
AUTO_VOTE_INTERVAL = 10

def auto_add_votes():
    while True:
        time.sleep(AUTO_VOTE_INTERVAL)
        for candidate in votes:
            votes[candidate] += 1

thread = Thread(target=auto_add_votes, daemon=True)
thread.start()

@app.route('/')
def index():
    return render_template('index.html', candidates=votes)

@app.route('/vote', methods=['POST'])
def vote():
    data = request.json
    user_id = data.get('user_id')
    selected = data.get('selected')
    if not user_id or not selected or len(selected) != 6:
        return jsonify({'status': 'error', 'message': '請選擇六位不同候選人'}), 400
    if user_id in user_votes:
        return jsonify({'status': 'error', 'message': '您已經投票過了'}), 400
    if len(set(selected)) != 6:
        return jsonify({'status': 'error', 'message': '請勿重複投票同一位候選人'}), 400
    for c in selected:
        if c in votes:
            votes[c] += 1
    user_votes[user_id] = selected
    return jsonify({'status': 'success', 'message': '投票成功', 'votes': votes})

@app.route('/votes')
def get_votes():
    sorted_votes = dict(sorted(votes.items(), key=lambda x: x[1], reverse=True)[:41])
    return jsonify(sorted_votes)

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000)
